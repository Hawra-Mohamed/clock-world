# World Clock

## Available Scripts

This project was created using with Vitejs. In the project directory, please run the following commands:

`npm install`

`npm run dev`

The second command will run the app
To see the rendered output please open http://localhost:5173 in the browser of your choice, EG: Google Chrome.

The page will reload when you make changes.
You may also see any lint errors in the console.
