import Logo from "/Logo.webp";
import "./App.css";
import Clock from "../Clock";
function App() {
  return (
    <>
       <div>
      <img src={Logo} className="img"/>
      </div>

      <h1>World Clock</h1>
      
      <div className="card">
       <Clock timeZone="America/Los_Angeles"/>
       <Clock timeZone="Europe/London"/>
       <Clock timeZone="Asia/Singapore"/>
      </div>
    </>
  );
}


export default App;
